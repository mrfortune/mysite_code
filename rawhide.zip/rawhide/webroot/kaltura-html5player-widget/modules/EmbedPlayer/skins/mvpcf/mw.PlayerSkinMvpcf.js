/*
mvpcf skin config
*/

mw.PlayerSkinMvpcf = {
	playerClass : 'mv-player'
};