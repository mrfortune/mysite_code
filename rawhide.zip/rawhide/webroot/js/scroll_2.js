// JavaScript Document

<!--//
$(function(){
	function moveFloatMenu() {
		var menuOffset = menuYloc.top + $(this).scrollTop() + "px";
		$('#fl_menu').animate({top:menuOffset},{duration:500,queue:false});
	}
 
	menuYloc = $('#fl_menu').offset();
 
	$(window).scroll(moveFloatMenu);
 
	moveFloatMenu();
});
//-->
